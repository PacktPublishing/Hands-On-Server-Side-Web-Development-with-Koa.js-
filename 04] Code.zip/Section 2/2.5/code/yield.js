function* list(){
    for(i=0; i<= 10; i++){
       yield i
    }
}


var output = list()

