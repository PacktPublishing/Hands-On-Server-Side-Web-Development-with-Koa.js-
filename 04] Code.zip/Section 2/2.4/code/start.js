require('@babel/register')({})
module.exports = require('./app');